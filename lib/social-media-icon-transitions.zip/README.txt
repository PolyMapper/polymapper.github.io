A Pen created at CodePen.io. You can find this one at https://codepen.io/Mattykins/pen/ZYYoNX.

 Consolidated all of the different social media icon styles I've been seeing recently into one pen, enjoy